#!/usr/bin/env python
# coding: utf-8

# In[28]:


import pandas as pd
import re
df = pd.read_csv('C:/Users/Jai Varia/Downloads/financial_data_SEC.xlsx.csv')


# In[29]:


df.iloc[:9, :7]


# In[30]:


numeric_cols = ['Total Revenue', 'Net Income', 'Total Assets', 'Total Liabilities', 'Cash flow from Operation']

for col in numeric_cols:
    df[col] = df[col].astype(str).str.replace(',','')
    df[col] = pd.to_numeric(df[col], errors='coerce')


# In[31]:


df[numeric_cols] = df[numeric_cols].fillna(0)


# In[40]:


def Total_Revenue(company=None, year=None):
    if company:
        if year:
            revenue = df[(df["Company"].str.lower() == company.lower()) & (df['Year'] == year)]['Total Revenue'].sum()
            if revenue == 0:
                return f"The financial data for {company.title()} in {year} is not available"
            return f"The Total Revenue of {company.title()} in {year} is {revenue} USD"
        else:
            revenue = df[df["Company"].str.lower() == company.lower()]['Total Revenue'].sum()
            return f"The Total Revenue of {company.title()} is {revenue} USD"
    else:
        if year:
            revenue = df[df["Year"] == year]['Total Revenue'].sum()
            return f"The Total Revenue of all companies in {year} is {revenue} USD"
        else:
            revenue = df["Total Revenue"].sum()
            return f"The Total Revenue of all companies is {revenue} USD"


# In[52]:


def Total_Assets(company=None, year=None):
    if company:
        if year:
            assets = df[(df["Company"].str.lower() == company.lower()) & (df['Year'] == year)]['Total Assets'].sum()
            if assets == 0:
                return f"The financial data for {company.title()} in {year} is not available"
            return f'The Total Assets of {company.title()} in {year} is {assets} USD'
        else:
            assets = df[df['Company'].str.lower() == company.lower()]['Total Assets'].sum()
            return f'The Total Assets of {company.title()} is {assets} USD'
    else:
        if year:
            assets = df[df["Year"] == year]['Total Assets'].sum()
            return f'The Total Assets of all companies in {year} is {assets} USD'
        else:
            assets = df['Total Assets'].sum()
            return f'The Total Assets of all companies is {assets} USD'


# In[53]:


def net_income(company=None, year=None):
    if company:
        company = company.lower()
        if year:
            income = df[(df["Company"].str.lower() == company) & (df["Year"] == year)]['Net Income'].sum()
            if income == 0:
                return f"The financial data for {company.title()} in {year} is not available"
            return f"The net income of {company.title()} in {year} is {income} USD"
        else:
            income = df[df["Company"].str.lower() == company]['Net Income'].sum()
            return f"The total net income of {company.title()} is {income} USD"
    else:
        if year:
            income = df[df["Year"] == year]['Net Income'].sum()
            return f"The net income of all companies in {year} is {income} USD"
        else:
            income = df["Net Income"].sum()
            return f"The total net income of all companies is {income} USD"


# In[54]:


def net_income_change(company=None, start_year=None, end_year=None):
    years = sorted(df['Year'].unique())
    if start_year is None or end_year is None:
        start_year = years[-2]
        end_year = years[-1]

    if company:
        subset = df[(df['Company'].str.lower() == company) & (df['Year'].isin([start_year, end_year]))]
    else:
        subset = df[df['Year'].isin([start_year, end_year])]

    if subset['Year'].nunique() < 2:
        if company:
            return f"The financial data for {company.title()} is not available for the period {start_year}-{end_year}"
        else:
            return f"The financial data for all companies is not available for the period {start_year}-{end_year}"
    
    income_start = subset[subset['Year'] == start_year]['Net Income'].sum()
    income_end = subset[subset['Year'] == end_year]['Net Income'].sum()
    change = income_end - income_start
    trend = "increased" if change > 0 else "decreased"
    
    if company:
        return f"The net income of {company.title()} {trend} by {abs(change)} from {int(start_year)} to {int(end_year)}."
    else:
        return f"The net income of all the companies {trend} by {abs(change)} from {int(start_year)} to {int(end_year)}."


# In[57]:


def company_profit(company, year=None):
    company = company.lower()  
    if year is None:
        year = df['Year'].max()  

    subset = df[(df['Company'].str.lower() == company) & (df['Year'] == year)]
    
    if subset.empty:
        return f"The financial data for {company.title()} in {year} is not available"
    
    profit = subset['Net Income'].sum()
    
    if profit == 0:
        return f"The financial data for {company.title()} in {year} is not available"
    
    return f"The profit of {company.title()} in {year} was {profit} USD"


# In[58]:


def compare_Total_Revenue(company1, company2):
    try:
        rev1 = df[df['Company'].str.lower()==company1.lower()]['Total Revenue'].values[0]
        rev2 = df[df['Company'].str.lower()==company2.lower()]['Total Revenue'].values[0]
        diff = abs(rev1 - rev2)
        return f"{company1.title()}'s revenue is {rev1} USD, {company2.title()}'s revenue is {rev2}USD . The difference is {diff} USD"
    except:
        return f"Couldnt compare, please check Company names"


# ## Chatbot building

# In[61]:


import re

def financial_chatbot():
    print("hello I am professional chatbot")
    print("You can ask question based on Microsoft, Tesla and apple")
    print("You can ask financial data related questions about the companies")
    print("Type 'EXIT' to quit.\n")

    last_company = None

    while True:
        user_input = input("You:").casefold().strip()

        # Company
        company = None
        if "all company" in user_input or "all companies" in user_input:
            company = None
        else:
            companies_in_input = [c for c in ["microsoft", "apple", "tesla"] if c in user_input]
            if len(companies_in_input) == 2:
                print("Chatbot:", compare_Total_Revenue(companies_in_input[0], companies_in_input[1]))
                continue 
            elif len(companies_in_input) == 1:
                company = companies_in_input[0]
                last_company = company
            elif not companies_in_input and last_company:
                company = last_company


        # Extract year for revenue/asset queries
        year_in_input = re.findall(r'\b(2022|2023|2024)\b', user_input)
        if len(year_in_input) >= 1:
            year = int(year_in_input[0])  # take the first year mentioned
        else:
            year = None  # or you can default to 2024



        # intention
        if user_input == "exit":
            print("chatbot: Goodbye!")
            break
        elif "revenue" in user_input:
            print("Chatbot:", Total_Revenue(company=company, year=year))
        elif "assets" in user_input:
            print("Chatbot:", Total_Assets(company=company, year=year))
        elif "net income" in user_input or "profit" in user_input:
            if "how" in user_input or "change" in user_input or "trend" in user_input:
                print("Chatbot:", net_income_change(company=company, start_year=start_year, end_year=end_year))
            elif company:
                print("Chatbot:", net_income(company=company, year=year))
            else:
                print("Chatbot: Please specify a company name.")
        elif "compare" in user_input and company and last_company and company != last_company:
            print("Chatbot:", compare_Total_Revenue(company, last_company))
        else:
            print("Chatbot: Sorry! I didn't understand your question. Kindly ask about company revenue, net income, or comparisons.")


# In[62]:


financial_chatbot()


# In[ ]:




